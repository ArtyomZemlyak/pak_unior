﻿PAK UNIOR
==============

PAK UNIOR EEG repository

* Matplotlib and Web PLOT GRAPH

To install:
-----------------

1. Install **Anaconda**

    .. _**anaconda**: https://www.anaconda.com/products/individual

2. Use:

    .. code-block::

        conda env create -f environment.yml
    
   This install vertual env using conda. 2.5 Gb req, but have a lot of tools.
  
3. And can clone this rep, and run:

    .. code-block::
  
        python main.py
    
4. Or use class **PlotDenamicUpdate** (check **main.py**)
   to initialize web server with program pak_unior.

5. Or use **runner.exe** file (also u can create link to this file on desktop).

   ! But you need install **anaconda** and **env** into default dir.
