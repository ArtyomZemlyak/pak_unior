.. automodule:: PlotDynamicUpdate
	:members:
	:undoc-members:
	:show-inheritance: